const express=require('express')
const app = express();
const server = require("http").createServer(app);
const io = require("socket.io")(server, { cors: { origin: "*" } });
import { Utility } from "./rmq/utility";
var utility = Utility.getInstance();
var cors = require("cors");
import { default as axios } from "axios";
import { Dictionary } from "dictionaryjs";
const port = 5001;
app.use(express.json())
app.use(cors());

let activeDictionary = new Dictionary();

io.on("connection", function (socket) {
   activeDictionary.set("socketID", socket.id);
    socket.emit("generateID", socket.id);
});


app.post("/:service_name/:SocketId", (req:any, res:any) => {
    const data = req.body;
    const topicName = req.params.service_name + "_ADD";//EMPLOYEE_ADD
   console.log(data)
    const body = {

        data:data
    }
    const response = utility.PublicMessageToTopic(topicName, body);
    res.json(response);
});

app.put("/:service_name/:sockeId", (req:any, res:any) => {
    const topicName = req.params.service_name + "_UPDATE";   
    const requestModelQuery= req.headers["requestquerymodel"]
    const requestModelQuery_temp=JSON.parse(requestModelQuery);
    const body = {
        id: requestModelQuery_temp.filter.conditions[0].field_value,
        data: req.body,
    }
    const response = utility.PublicMessageToTopic(topicName, body);
    res.json(response);
});


app.delete("/:service_name/:socketId", (req:any, res:any) => {
    const requestModelQuery= req.headers["requestquerymodel"];
    let topicName = req.params.service_name + "_DELETE"; 
    const response = utility.PublicMessageToTopic(topicName,requestModelQuery);
    res.json(response);
});


app.get("home/:service_name/:socketId", async (req:any, res:any) => {
    try {
        let service_name = req.params.service_name;
        let url = evaluate_service_routes(service_name)
        console.log(url);
        let result = await axios.get(url);
        console.log(result.data);
        res.status(result.status).send(result.data);
    }
    catch (e) {
        console.log("Error in Axios")
    }

});


function evaluate_service_routes(service_name:string)
{
    let response:string;
    if (service_name.localeCompare("HRService") == 0) {
      switch (service_name) {
        case 'EMPLOYEE': response = 'http://localhost:8000/' + 'Employee';
          break;
        case 'DEPARTMENT': response = 'http://localhost:8000/' + 'Department';
          break;
        case 'EMPLOYEEDEPARTMENT': response = 'http://localhost:8000/' + 'EmployeeDepartment';
          break;
        default: return "No Module found";
      }
    }
    else {
      response = "No Service Found";
    }
    return response;
}
  

server.listen(port, () => {
    console.log("Server Runnig on : ", port);
    utility.listenToServices("API_GATEWAY_SERVICE", (result:any) => {
        const { message } = result;
        console.log(message);
    });
});







