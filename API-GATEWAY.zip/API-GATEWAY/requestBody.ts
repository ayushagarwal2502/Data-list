export default class RequestBodyDto {
    data: {};
  }