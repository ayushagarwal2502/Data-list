import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
} from '@nestjs/common';
import { Injectable } from "@nestjs/common";
import DepartmentService from "src/AppService/DepartmentService";
import { DepartmentDto } from "src/Dtos/DepartmentDto";
import Department from "src/Entities/Department";
import ResponseModel from "src/Models/ReponseModel";
import FacadeBase from "./FacadeBase";

@Injectable()
export class DepartmentFacade  extends FacadeBase<DepartmentDto, Department>
{
    
    constructor(private readonly depAppService:DepartmentService){
        super(depAppService);
        
        console.log('printing empAppService class ');
        console.log(depAppService);
        //console.log(DepartmentFacade);
       // super(DepartmentAppService ?? new DepartmentAppService());
    }
    
}