import { Injectable } from "@nestjs/common";
import { AppService } from "src/app.service";
import { DepartmentDto } from "src/Dtos/DepartmentDto";
import { EmployeeDepartmentDto } from "src/Dtos/EmployeeDepartmentDto";
import Department from "src/Entities/Department";
import Employee from "src/Entities/Employee";
import EmployeeDepartment from "src/Entities/EmployeeDepartment";
import { EmployeeDepartmentRepository } from "src/Repositories/EmployeeDepartmentRepository";
import ApplicationService from "./ApplicationService";


@Injectable()
export default class EmployeeDepartmentsService extends ApplicationService<EmployeeDepartment, EmployeeDepartmentDto>{
    
    //private repository = new EmployeeDepartmentsServiceRepository();
//private readonly repository_temp:RepositoryBase<EmployeeDepartmentsService>
    constructor(EmployeeDepartmentRepository: EmployeeDepartmentRepository){
        super(EmployeeDepartmentRepository);
       // super(new EmployeeDepartmentRepository());

        //, temp_exployee_data_processing_function
        //todo: check how to pass func ref to contruction of base

        //super.repository
       // this.repository = repository_temp;
        
    }

    

    public exployee_data_processing_function(){

    }

    CreateEntityInstance(): EmployeeDepartment {
        let emp = new EmployeeDepartment();
        return emp;
    };



    CreateDtoInstance(): EmployeeDepartmentDto {
        let dto =  new EmployeeDepartmentDto();
       
        return dto;
    };

   /* ConvertDtoToEntity(dto: EmployeeDepartmentDto): EmployeeDepartment {
       let EmployeeDepartment_entity = new EmployeeDepartment();
        EmployeeDepartment_entity.department_id=dto.department_id;//undefined if not present
        EmployeeDepartment_entity.department=new Department();
        EmployeeDepartment_entity.department.department_name=dto.department_name;//name sent as object
        EmployeeDepartment_entity.employee_id=dto.employee_id;//undefined if not present
        EmployeeDepartment_entity.employee=new Employee();
        EmployeeDepartment_entity.employee.name=dto.employee_name;
        EmployeeDepartment_entity.employee.age=dto.employee_age;

        console.log("Dto to entity ",EmployeeDepartment_entity)
       return EmployeeDepartment_entity;
       

    }
    ConvertEntityToDto(entity: EmployeeDepartment): EmployeeDepartmentDto {
      let EmployeeDepartment_dto = new EmployeeDepartmentDto();
      EmployeeDepartment_dto.department_id=entity.department_id;
      EmployeeDepartment_dto.employee_id=entity.employee_id;
      EmployeeDepartment_dto.department=new DepartmentDto();
      
      return EmployeeDepartment_dto;
    }*/

    
    ConvertDtoToEntity(dto: EmployeeDepartmentDto): EmployeeDepartment {
        let EmployeeDepartment_entity = new EmployeeDepartment();
       EmployeeDepartment_entity.department_id=dto.department_id;
        EmployeeDepartment_entity.employee_id=dto.employee_id;
        return EmployeeDepartment_entity;
        
 
     }
     ConvertEntityToDto(entity: EmployeeDepartment): EmployeeDepartmentDto {
       let EmployeeDepartment_dto = new EmployeeDepartmentDto();
       EmployeeDepartment_dto.department_id=entity.department_id;
       EmployeeDepartment_dto.employee_id=entity.employee_id;
       return EmployeeDepartment_dto;
     }

}