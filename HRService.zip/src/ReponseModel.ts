
export default class ResponseModel{
    public status;
    public message;
    public method;
    public desc;
    public obj

constructor(status,message,method,desc,obj){
this.status=status;
this.message=message;
this.method=method;
this.desc=desc;
this.obj=obj;
    
}


} 