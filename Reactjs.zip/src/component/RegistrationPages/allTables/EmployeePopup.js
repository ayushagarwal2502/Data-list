import React,{useState} from 'react'
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

const EmployeePopup = ({ modal, id, handleChange, name, obj }) => {
    //for storing edit form details.   
    const [inputField, setInputField] = useState({})

    const inputsHandler = (e) => {
        e.preventDefault();
        setInputField((inputField) =>
        ({
            ...inputField,
            [e.target.name]: e.target.value,
        }));
    }
    //function edit to be performed on table data
    async function edit(event) {
        event.preventDefault();
        let employeeData1 = {
            name:inputField.Ename,
            name:inputField.gender,
            name:inputField.age,
            name:inputField.contact_no,
        }
        let service = "Employee";
        await fetch(`http://localhost:5001/${name}/update/${service}/${id}`, {  // Enter your IP address here

            method: 'PUT',
            mode: 'cors',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(employeeData1) // body data type must match "Content-Type" header
        });
        handleChange();
    }
    return (
        <Modal isOpen={modal} toggle={handleChange}>
            <ModalHeader toggle={handleChange}>Edit</ModalHeader>
            <ModalBody>
                <div className="user-details">
                    <div className="input-box">
                        <span className="details">Employee Name</span>
                        <input type="text" name="Ename" defaultValue={obj.name} onChange={inputsHandler} placeholder="Enter Employee name" required />
                    </div>
                    <div className="input-field">
                    <span className="details"> Gender</span>
                     <select name="gender" required>
                          <option disabled selected>Select gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Others">Others</option>
                             </select>
                      </div>
                   
                    <div className="input-box">
                        <span className="details">Age</span>
                        <input type="number" name="age"   placeholder="Enter Employee age" required />
                    </div>
                    <div className="input-field">
                    <span className="details">Mobile Number</span>
                    <input type="number" name="contact" placeholder="Enter mobile number" required />
                    </div>

                </div>
            </ModalBody>
            <ModalFooter>
                <Button color="primary" onClick={edit}>Update</Button>{' '}
                <Button color="secondary" onClick={handleChange}>Cancel</Button>
            </ModalFooter>
        </Modal>
    )
}

export default EmployeePopup
