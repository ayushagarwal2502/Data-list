import React,{useState} from 'react'
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

const DepartmentPopup = ({ modal, id, handleChange, name, obj }) => {
    //for storing edit form details.   
    const [inputField, setInputField] = useState({})

    const inputsHandler = (e) => {
        e.preventDefault();
        setInputField((inputField) =>
        ({
            ...inputField,
            [e.target.name]: e.target.value,
        }));
    }
    //function edit to be performed on table data
    async function edit(event) {
        event.preventDefault();
        let departmentData1 = {
            name: inputField.name,
        }
        let service = "Department";
        await fetch(`http://localhost:5001/${name}/update/${service}/${id}`, {  // Enter your IP address here

            method: 'PUT',
            mode: 'cors',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(departmentData1) // body data type must match "Content-Type" header
        });
        handleChange();
    }

    return (
        <Modal isOpen={modal} toggle={handleChange}>
            <ModalHeader toggle={handleChange}>Edit</ModalHeader>
            <ModalBody>
                <div className="user-details">
                    <div className="input-box">
                        <span className="details">Department Name</span>
                        <input type="text" name="name" defaultValue={obj.name} onChange={inputsHandler} placeholder="Enter Department name" required />
                    </div>
                </div>
            </ModalBody>
            <ModalFooter>
                <Button color="primary" onClick={edit}>Update</Button>{' '}
                <Button color="secondary" onClick={handleChange}>Cancel</Button>
            </ModalFooter>
        </Modal>
    )
}

export default DepartmentPopup
