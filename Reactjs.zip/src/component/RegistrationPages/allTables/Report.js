import React, {useState} from 'react'
import Dashboard from '../Dashboard'

const Report = (props) => {
  const [empDepartDetails, setempDepartDetails] = useState([]);
  const edit = id => (event) => {
    event.preventDefault();
    console.log(id)
  }
  const remove = (id) => (event) => {
    event.preventDefault();
    console.log("Report deleted for id:", id);
    let service = "EMP_DEPARTMENT";
    const url = `http://localhost:5001/${props.name}/${service}/${id}`
    const xhr = new XMLHttpRequest();
    xhr.open("DELETE", url);
    xhr.send();
  }
  async function add(event) {
    event.preventDefault();
      let reportData ={
        fees: document.getElementById('fees').value,
        employee_ids: document.getElementById('eid').value,
        department_ids: document.getElementById('did').value,
      }
      let service = "EMP_DEPARTMENT";
      await fetch(`http://localhost:5001/${props.name}/${service}`, {  // Enter your IP address here

          method: 'POST',
          mode: 'cors',
          headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
          },
          body: JSON.stringify(reportData) // body data type must match "Content-Type" header
      });
    }
      function toDisplay(event) {
        event.preventDefault();
        const url = `http://localhost:5001/home/emp-department/${props.name}`;
        const xhr = new XMLHttpRequest();
        xhr.open("GET", url);
        xhr.onload = () => {
          setempDepartDetails(JSON.parse(xhr.response));
        }
        xhr.send();
      }
  
  return (
    <div>
      <Dashboard />
      <div className="container">
        <form id="form3" encType="multipart/form-data">
          <div className="user-details">
              <span className="details">Employee ID</span>
              <input type="text" id="eid" placeholder="Enter Employee id" required />
          
              <span className="details">Department ID</span>
              <input type="text" id="did" placeholder="Enter Departmnet id" required />
            
              <span className="details">Salary</span>
              <input type="number" id="salary" placeholder="Enter Salary for employee" required />
            
              <button onClick={add}>
                <span >Submit</span>
              </button>
            
          </div>
        </form>
      </div>
      <div className='table-container'>
      <button onClick={toDisplay}>Load</button>
        <table className="table table-hover">
          <thead id="tableHead">
            <tr>
              <th>ID <i className="fa fa-caret-down _idSort" aria-hidden="true"></i>
              </th>
              <th>Employee_name <i className="fa fa-caret-down nameSort" aria-hidden="true"></i>
              </th>
              <th>Departmnet_name <i className="fa fa-caret-down nameSort" aria-hidden="true"></i>
              </th>
              <th>Salary <i className="fa fa-caret-down nameSort" aria-hidden="true"></i>
              </th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="Report">
          { 
            empDepartDetails && empDepartDetails.map((index) => <><tr>
              <td>{index.emp_Department_id}</td>
              <td>{index.employee['fname']+" "+index.employee['lname']}</td>
              <td>{index.department['name']}</td>
              <td>{index.salary}</td>
              <td>
                <button onClick={edit(index.emp_department_id)}>
                  <i className="material-icons" id="edit">edit</i>
                </button>
                <button onClick={remove(index.emp_department_id)}>
                  <i className="material-icons" id="delete">delete</i>
                </button>
              </td>
            </tr></>)

            }
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default Report
