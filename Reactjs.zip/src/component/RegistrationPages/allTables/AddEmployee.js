import React from 'react'
import Dashboard from '../Dashboard'
import './employee.css'

const AddEmployee = (props) => {

    async function add(event) {
        event.preventDefault();
        //create employee object with all data
        let empData = {
            "name": document.getElementById('name').value,
            "gender": document.getElementById('gender').value,
            "age": parseInt(document.getElementById('age').value),
            "contact_no": parseFloat(document.getElementById('contact').value),
           
        }
        let service = "EMPLOYEE";


        await fetch(`http://localhost:5001/${props.name}/${service}`, {  // Enter your IP address here

            method: 'POST',
            mode: 'cors',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(empData) // body data type must match "Content-Type" header
        });

    }
    return (
        <div>
            <Dashboard />
            <div className="container">
                <form encType="multipart/form-data" >
                    <div className="form" >
                        <div className="details personal">
                            <span className="title">Employee Details</span>

                            <div className="fields">

                                <div className="input-field">
                                    <label> Name</label>
                                    <input type="text" id="name" placeholder="Enter your  name" required />
                                </div>

                                <div className="input-field">
                                    <label>Gender</label>
                                    <select id="gender" required>
                                        <option disabled selected>Select gender</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Others">Others</option>
                                    </select>
                                </div>

                                <div className="input-field">
                                    <label>Age</label>
                                    <input type="number" id="age" placeholder="Enter your age" required />
                                </div>

                                <div className="input-field">
                                    <label>Mobile Number</label>
                                    <input type="number" id="contact" placeholder="Enter mobile number" required />
                                </div>

                                <div className="input-field">
                                    <label>Department-ID</label>
                                    <input type="text" placeholder="Enter department ID to register" required />
                                </div>
                            </div>
                           

                                <button className="submitBtn" onClick={add}>
                                    <span className="btnText" >Submit</span>
                                </button>
                            
                        </div>

                    </div>        </form>
            </div>


        </div>
    )
}

export default AddEmployee
