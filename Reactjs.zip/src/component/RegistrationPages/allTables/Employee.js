import React, { useState } from 'react'
import Dashboard from '../Dashboard';
import './employee.css'
import EmployeePopup from './EmployeePopup';


const Employee = (props) => {

  const [employeeDetails, setEmployeeDetails] = useState([]);
  //deleting the student table entry on request
  const remove = (eid) => (event) => {
    event.preventDefault();
    console.log("Employee info deleted with id:", eid);
    let service = "EMPLOYEE";
    const url = `http://localhost:5001/${props.name}/${service}/${eid}`
    const xhr = new XMLHttpRequest();
    xhr.open("DELETE", url);
    xhr.send();
  }

  // to fetch the data from the url below and display using show function
  function toDisplay(event) {
    event.preventDefault();

    const url = `http://localhost:5001/home/Employee/${props.name}`;
    const xhr = new XMLHttpRequest();
    xhr.open("GET", url);
    xhr.onload = () => {
      setEmployeeDetails(JSON.parse(xhr.response));
    }
    xhr.send();
    console.log(employeeDetails);
  }
  //for edit modal
  const [isOpen, setIsOpen] = useState(false);
  const [empId, setEmpId] = useState(0);
  const [getObject, setObject] = useState({});
  const togglePopup = () => {
    setIsOpen(!isOpen);
  }

  return (
    <div>
      <Dashboard />
      <div className='table-container'>
        <button onClick={toDisplay}>Load</button>
        <table className="table table-hover">
          <thead id="tableHead">
            <tr>
              <th>ID <i className="fa fa-caret-down _idSort" aria-hidden="true"></i>
              </th>
              <th>name <i className="fa fa-caret-down nameSort" aria-hidden="true"></i>
              </th>
              <th>Gender <i className="fa fa-caret-down nameSort" aria-hidden="true"></i>
              </th>
              <th>Age <i className="fa fa-caret-down nameSort" aria-hidden="true"></i>
              </th>
              <th>Contact-no <i className="fa fa-caret-down nameSort" aria-hidden="true"></i>
              </th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="students-list">
            {
              employeeDetails && employeeDetails.map((index) => <><tr>
                <td>{index.employee_id}</td>
                <td>{index.name}</td>
                <td>{index.gender}</td>
                <td>{index.age}</td>
                <td>{index.contact_no}</td>
                <td>
                  <button onClick={() => { setIsOpen(true); setEmpId(index.student_id);  setObject(index) }}>
                    <i className="material-icons" id="edit">edit</i>
                  </button>
                  <EmployeePopup modal={isOpen} sid={empId} handleChange={togglePopup} name={props.name} obj={getObject} />

                  <button onClick={remove(index.employee_id,)}>
                    <i className="material-icons" id="delete">delete</i>
                  </button>
                </td>
              </tr>
              </>
              )
              
            }
            
          </tbody>
        </table>
       </div>
    </div>

  )
}

export default Employee;
