import React from 'react'
import Dashboard from '../Dashboard'
import './department.css'
import './employee.css'

const AddDepartment = (props) => {

  async function addDepartment(event) {
    event.preventDefault();
    let departmentData = {
      name: document.getElementById('dname').value,
    }
    let service = "DEPARTMENT";
    await fetch(`http://localhost:5001/${props.name}/${service}`, {  // Enter your IP address here

      method: 'POST',
      mode: 'cors',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(departmentData) // body data type must match "Content-Type" header
    });
  }
  return (
    <div>
      <Dashboard />
      <div className="container">
        <form encType="multipart/form-data">
          <div className="form ">
            <div className="user-details">
              <div className="input-box">
                <span className="details">Department Name</span>
                <input type="text" id="dname" placeholder="Enter Department name" required />
              </div>
            </div>
            <button className="submitBtn" onClick={addDepartment}>
              <span className="btnText">Submit</span>
            </button>
          </div>
        </form>
      </div>
    </div >

  )
}

export default AddDepartment
