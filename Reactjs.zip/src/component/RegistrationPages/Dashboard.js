import React from 'react'
import './style.css'
import { Link } from "react-router-dom";


const Dashboard = () => {


    return (
        <>
            <div className='header'>
                Employee-Department Registration</div>
            <div className='left-navibar'>
                <ul>
                    <li><Link className="nav-item" to="/dashboard/employee">Employee</Link></li>
                    <li><Link className="nav-item" to="/dashboard/add-employee">Add Employee</Link></li>
                    <li><Link className="nav-item" to="/dashboard/department">Department</Link></li>
                    <li><Link className="nav-item" to="/dashboard/add-department">Add Department</Link></li>
                    <li><Link className="nav-item" to="/dashboard/report">Report</Link></li>
                </ul>
            </div>
                             
       </>          
    )
}

export default Dashboard;
