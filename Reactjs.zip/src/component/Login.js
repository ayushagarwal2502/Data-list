import React, { useState, useEffect } from 'react'
import './login.css';
import jwt_decode from 'jwt-decode';
import {useNavigate } from 'react-router'

const Login = () => {
       //used to store the value of user Information 
       const [user,setUser] =useState({});
       const [logUser, setLogUser] = useState('');
       let navigate =useNavigate();

    function handleCallbackResponse(response) {
        // jwt help to convert the access token to meaning full information
        var userObject = jwt_decode(response.credential);
        console.log(userObject);
        setUser(userObject);
        navigate("/dashboard");
    }
    //if login credentials are right redirect to dashboard
    function redirect(){
        navigate("/dashboard");         
    }
   // google account login 
    useEffect(() => {
        /*global google*/
        google.accounts.id.initialize({
            client_id:"520829387299-adfos9gcn8hgt0vf7lld2ic24ae7lc6d.apps.googleusercontent.com",
            callback: handleCallbackResponse
        });

        google.accounts.id.renderButton(
            document.getElementById("signInDiv"),
            {  size: "large", align: "center" }
        )
    });

    const updateLogUser = (e) =>{
        setLogUser(e.target.value);
    }

    function handlelogin(){
        if(logUser === "Ayush")
            redirect();
    }

    return (
       <div className="box-form">
           <div className="left">
               <div className="overlay">
                   <h1>Employee-Department Registration</h1><br></br>
                   <p>Details of Employee with Department</p>
                       <div id="signInDiv"></div>
                       {user.name ? redirect: false}
               </div>
           </div>
           <div className="right">
               <h5>Login</h5>
               <p>Don't have an account? <a href="/">Create Your Account</a></p>
               <div className="inputs" >
                   <input type="text" placeholder="user name" value={logUser} onChange={updateLogUser} required/>
                   <br />
                   <input type="password" placeholder="password" required/>
                   <p>Forget password?</p>
               </div>
               <button onClick={handlelogin}>Login</button>
           </div>
        </div>
    )
}
export default Login;

