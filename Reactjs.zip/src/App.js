import './App.css';
import Login from './component/Login';
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import Dashboard from './component/RegistrationPages/Dashboard';
import Employee from './component/RegistrationPages/allTables/Employee'; 
import AddEmployee from './component/RegistrationPages/allTables/AddEmployee';
import Department from './component/RegistrationPages/allTables/Department';
import AddDepartment from './component/RegistrationPages/allTables/AddDepartment';
import Report from './component/RegistrationPages/allTables/Report';
import io from 'socket.io-client'
const socket = io("http://localhost:5001");


function App() {
  //socket connection
  socket.on("connection");
  var socketId;
      // receiveing generated socket id
  socket.on("generateID", (result) =>{
    socketId =result;
    console.log("socketID", result);
  });
  


  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
        <Route exact path="/" element={<Login/>}/>
      </Routes>
      <Routes>
        <Route  path="/dashboard" element={<Dashboard/>}/>
      <Route  path="/dashboard/Employee" element={<Employee conn={socketId}/>} />
      <Route path="/dashboard/add-employee" element={<AddEmployee/>} />
      <Route  path="/dashboard/Department" element={<Department />} />
      <Route path="/dashboard/add-department" element={<AddDepartment/>} />
      <Route path="/dashboard/report" element={<Report />} />
      </Routes>
      </BrowserRouter> 
    </div>
  );
}

export default App;
